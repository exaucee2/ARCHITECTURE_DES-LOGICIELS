package seg3502.calculator_api

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class CalculatorApiApplicationTests {

	@Test
	fun contextLoads() {
	}

}
